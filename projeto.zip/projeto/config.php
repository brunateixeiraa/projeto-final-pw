<?php

    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword ='';
    $dbName = 'napolean';

    $conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

    if($conexao->connect_errno)
    {
        echo "Erro";
    }
    else
    { // echo '<p class="cor"><b>Conexão efetuada com sucesso</b></p>';
    }

?>

<style>
    .cor{
        color: rgba(28, 152, 197, 0.916);
    }
</style>
